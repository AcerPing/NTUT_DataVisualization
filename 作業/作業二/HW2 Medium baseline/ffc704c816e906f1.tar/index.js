export {default} from "./ffc704c816e906f1@36.js";
